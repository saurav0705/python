def f(*a):
    print(a)


f(1.2,2.1,3)