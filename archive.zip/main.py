def main():
  print ("Hello World!")
  print ("in main")


print ("Guru99:not called main")
if __name__=="__main__":
 main()