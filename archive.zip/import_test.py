from  add import add,mul

def new():
    print ("new block")

add(4,5)
print (mul(8,9))
new()
