def operators():
    x=5
    y=5
    print(x**y)


operators()