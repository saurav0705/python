f=100

def mul():
    return(f*f)

def txt():
    f="this is now string"
    print (f)
def again():
    f=10.1111
    print(f)

print (mul())
txt()
again()