name="saurav"


def conversion():
    a=10
    b=20
    print("the total is : "+str(a+b))




if __name__=="__main__":
    conversion()    
