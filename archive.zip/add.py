def add(a,b):
    print(a+b)

def mul(a,b):
    return(a*b)

if __name__=="__main__":
 add(4,5)
 print (mul(4,5))

print("in add::"+__name__) 